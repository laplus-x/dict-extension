chrome.runtime.onConnect.addListener(e=>{e.name==="popup"&&(e.postMessage({type:"VISIBLE",visible:!0}),e.onDisconnect.addListener(s=>{s.postMessage({type:"VISIBLE",visible:!1})}))});
